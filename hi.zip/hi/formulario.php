<?php

echo "hola";


//dayClick: function(event,jsEvent,view){
	   //$("#eventLink").attr("http://localhost/hi/formulario.php",event.url);
	 //  $("#eventContent").dialog({modal: true, title:event.title});
   //},
   
   //<div id="eventContent" title="Event Details"><div id="eventInfo"> </div> <p><strong><a id="eventLink" target="_blank"> Read More</a></strong></p> </div>
   ?>